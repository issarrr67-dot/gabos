# GABOS Ticketing Launch Kit

**Event:** 17 November 2026  
**Venue:** To be announced  
**Tickets:** Early Bird KES 500 · General Entry KES 1,000 · Group Pass (4 people) KES 2,500  
**Brand direction:** dark charcoal, cream, neon-lime; “Good People. Good Energy. Lasting Memories.”

## Included

- `public/index.html` — responsive GABOS event and ticket-selection website.
- `public/gabos-brand-concept.png` — generated visual concept for the brand.
- `server/server.js` — Node/Express starter backend with:
  - ticket-price validation on the server;
  - M-Pesa STK Push request through Safaricom Daraja;
  - callback processing plus a Daraja STK status query before marking an order paid;
  - SQLite order/ticket records;
  - unique ticket numbers and QR codes sent by email when SMTP is configured;
  - ticket verification endpoint.
- `.env.example` — configuration template.

## Important: this is a launch kit, not a live payment service yet

The project cannot charge anyone until you have a Daraja app and credentials, a public HTTPS deployment, a callback URL registered/accepted for your setup, and a properly configured email sender. Do not advertise ticket sales as live until sandbox and production tests succeed. Never share your M-Pesa PIN or put credentials in frontend code.

## Run locally

Requires Node.js 20 or later.

1. Extract the ZIP and open the project folder in a terminal.
2. Install packages:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and configure it. Keep `.env private.
4. For initial website-only preview, leave Daraja credentials empty and run:

   ```bash
   npm start
   ```

5. Open `http://localhost:3000`. The ticket site displays, but checkout will clearly report that M-Pesa is not configured.

## Configure M-Pesa

1. Create/verify the appropriate Safaricom Daraja developer/business setup and create an app with the required STK Push permissions.
2. Use sandbox credentials first. Fill in `DARAJA_CONSUMER_KEY`, `DARAJA_CONSUMER_SECRET`, `DARAJA_SHORTCODE`, and `DARAJA_PASSKEY`.
3. Deploy to a public host with HTTPS and set `PUBLIC_BASE_URL` to that exact origin. Safaricom must be able to reach `POST /api/mpesa/callback`.
4. Verify the shortcode, transaction type, callback requirements and test phone numbers against the Daraja product/account configuration. `CustomerPayBillOnline` is a common PayBill STK Push transaction type; the correct type depends on your account.
5. Configure SMTP for ticket confirmation emails.
6. Test successful payments, cancelled prompts, wrong PINs, timeouts, duplicate callbacks, email failures and order status polling in sandbox before production.

The sample uses the Daraja STK Push API and an STK query for an extra status check. Safaricom's exact response fields and onboarding requirements may vary by account/product; test against current official documentation before going live. Payment callback processing is asynchronous and should be monitored in production.

## API overview

- `GET /api/health` — basic status.
- `POST /api/checkout` — `{ "name", "email", "phone", "ticketType", "quantity" }`; ticket types are `early`, `general`, `group`.
- `POST /api/mpesa/callback` — Daraja callback.
- `GET /api/orders/:id` — order status.
- `GET /api/tickets/verify/:ticketNumber` — basic ticket verification result.

## Before public launch

- Replace or supplement the generated brand-concept artwork with final approved logo/poster assets.
- Add the organizer's real support email/social links and terms/refund/privacy policies.
- Set ticket inventory and Early Bird cutoff if applicable.
- Add admin authentication and a secure check-in interface that can mark tickets as redeemed; do not use the public verification endpoint as the only event-entry control.
- Add robust callback reconciliation, alerting, backups, monitoring, privacy controls and a deployment secret manager.
- Confirm whether the Group Pass is one order for four separately scannable admissions (this starter issues four ticket QR codes per Group Pass).
- Review legal, tax, consumer-protection and data-protection requirements that apply to the organizer.

This starter is provided to help you build the system; it does not mean a Daraja account, hosting, domain, email service or payment acceptance has been activated.
