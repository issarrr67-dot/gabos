import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";
import QRCode from "qrcode";
import nodemailer from "nodemailer";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.PUBLIC_BASE_URL || "").replace(/\/$/, "");
const DARAJA_BASE = process.env.DARAJA_ENV === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

if (process.env.NODE_ENV === "production" && (!BASE_URL.startsWith("https://") || !process.env.DARAJA_CONSUMER_KEY || !process.env.DARAJA_CONSUMER_SECRET || !process.env.DARAJA_SHORTCODE || !process.env.DARAJA_PASSKEY)) {
  console.error("Missing production configuration: PUBLIC_BASE_URL (HTTPS) and Daraja credentials are required.");
  process.exit(1);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 40, standardHeaders: true, legacyHeaders: false }));

const db = new Database(process.env.DB_PATH || path.join(__dirname, "gabos.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL,
 ticket_type TEXT NOT NULL, quantity INTEGER NOT NULL, amount INTEGER NOT NULL,
 status TEXT NOT NULL, merchant_request_id TEXT, checkout_request_id TEXT,
 mpesa_receipt TEXT, created_at TEXT NOT NULL, paid_at TEXT
);
CREATE TABLE IF NOT EXISTS tickets (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL, ticket_number TEXT NOT NULL UNIQUE,
 status TEXT NOT NULL DEFAULT 'valid', created_at TEXT NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id)
);`);

const TICKETS = {
  early: { label: "Early Bird", price: 500, entries: 1 },
  general: { label: "General Entry", price: 1000, entries: 1 },
  group: { label: "Group Pass (4 people)", price: 2500, entries: 4 }
};
const money = n => `KES ${Number(n).toLocaleString("en-KE")}`;
const now = () => new Date().toISOString();

function requireDarajaConfig() {
  return ["DARAJA_CONSUMER_KEY","DARAJA_CONSUMER_SECRET","DARAJA_SHORTCODE","DARAJA_PASSKEY","PUBLIC_BASE_URL"]
    .filter(k => !process.env[k]);
}
function normalizeKenyanPhone(raw) {
  const digits = String(raw || "").replace(/[^\d]/g, "");
  if (/^07\d{8}$/.test(digits)) return "254" + digits.slice(1);
  if (/^01\d{8}$/.test(digits)) return "254" + digits.slice(1);
  if (/^254[17]\d{8}$/.test(digits)) return digits;
  throw new Error("Enter a valid Kenyan M-Pesa number, e.g. 0712345678.");
}
async function accessToken() {
  const missing = requireDarajaConfig();
  if (missing.length) throw new Error("M-Pesa checkout is not configured yet. Ask the GABOS team to finish setup.");
  const auth = Buffer.from(`${process.env.DARAJA_CONSUMER_KEY}:${process.env.DARAJA_CONSUMER_SECRET}`).toString("base64");
  const res = await fetch(`${DARAJA_BASE}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` }
  });
  const data = await res.json();
  if (!res.ok || !data.access_token) throw new Error("Could not authenticate with M-Pesa. Please try again later.");
  return data.access_token;
}
function darajaTimestamp(date = new Date()) {
  const p = n => String(n).padStart(2, "0");
  return `${date.getFullYear()}${p(date.getMonth()+1)}${p(date.getDate())}${p(date.getHours())}${p(date.getMinutes())}${p(date.getSeconds())}`;
}
async function startStkPush(order, phone) {
  const token = await accessToken();
  const timestamp = darajaTimestamp();
  const shortcode = process.env.DARAJA_SHORTCODE;
  const password = Buffer.from(`${shortcode}${process.env.DARAJA_PASSKEY}${timestamp}`).toString("base64");
  const body = {
    BusinessShortCode: shortcode,
    Password: password,
    Timestamp: timestamp,
    TransactionType: process.env.DARAJA_TRANSACTION_TYPE || "CustomerPayBillOnline",
    Amount: order.amount,
    PartyA: phone,
    PartyB: shortcode,
    PhoneNumber: phone,
    CallBackURL: `${BASE_URL}/api/mpesa/callback`,
    AccountReference: `GABOS-${order.id.slice(0,8).toUpperCase()}`,
    TransactionDesc: `GABOS ${TICKETS[order.ticket_type].label}`.slice(0, 13)
  };
  const res = await fetch(`${DARAJA_BASE}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!res.ok || data.ResponseCode !== "0" || !data.CheckoutRequestID) {
    console.error("Daraja STK push rejected:", data);
    throw new Error("M-Pesa could not start this payment. Check the number and try again.");
  }
  db.prepare("UPDATE orders SET merchant_request_id=?, checkout_request_id=? WHERE id=?")
    .run(data.MerchantRequestID || null, data.CheckoutRequestID, order.id);
  return data;
}
async function queryStkStatus(checkoutRequestId) {
  const token = await accessToken();
  const timestamp = darajaTimestamp();
  const shortcode = process.env.DARAJA_SHORTCODE;
  const password = Buffer.from(`${shortcode}${process.env.DARAJA_PASSKEY}${timestamp}`).toString("base64");
  const res = await fetch(`${DARAJA_BASE}/mpesa/stkpushquery/v1/query`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ BusinessShortCode: shortcode, Password: password, Timestamp: timestamp, CheckoutRequestID: checkoutRequestId })
  });
  const data = await res.json();
  if (!res.ok) throw new Error("Daraja payment status query failed.");
  return data;
}
const insertTickets = db.prepare("INSERT INTO tickets (id, order_id, ticket_number, status, created_at) VALUES (?,?,?,?,?)");
async function issueTickets(orderId) {
  const order = db.prepare("SELECT * FROM orders WHERE id=? AND status='paid'").get(orderId);
  if (!order) return [];
  const existing = db.prepare("SELECT * FROM tickets WHERE order_id=?").all(orderId);
  if (existing.length) return existing;
  const tickets = [];
  const entries = TICKETS[order.ticket_type].entries;
  for (let i=0; i<order.quantity * entries; i++) {
    const id = crypto.randomUUID();
    const ticketNumber = `GABOS-${new Date().getFullYear()}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
    insertTickets.run(id, orderId, ticketNumber, "valid", now());
    tickets.push({ id, ticket_number: ticketNumber, status: "valid" });
  }
  await sendConfirmation(order, tickets);
  return tickets;
}
async function sendConfirmation(order, tickets) {
  if (!process.env.SMTP_HOST || !process.env.MAIL_FROM) {
    console.warn(`SMTP not configured. Paid order ${order.id}; ticket numbers: ${tickets.map(t=>t.ticket_number).join(", ")}`);
    return;
  }
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } : undefined
  });
  const cards = await Promise.all(tickets.map(async t => {
    const qr = await QRCode.toDataURL(`${BASE_URL}/api/tickets/verify/${encodeURIComponent(t.ticket_number)}`);
    return `<li><strong>${t.ticket_number}</strong><br><img alt="Ticket QR code" width="160" height="160" src="${qr}"></li>`;
  }));
  await transport.sendMail({
    from: process.env.MAIL_FROM, to: order.email,
    subject: "Your GABOS ticket confirmation",
    html: `<div style="font-family:Arial,sans-serif;color:#171717"><h1>You're in, ${escapeHtml(order.name)}!</h1><p>Your GABOS payment is confirmed.</p><p><strong>${escapeHtml(TICKETS[order.ticket_type].label)}</strong> · ${order.quantity} order unit(s) · ${money(order.amount)}</p><p>17 November 2026 · Venue to be announced</p><ul>${cards.join("")}</ul><p>Keep this email and show your ticket QR code at entry.</p><p>Good people. Good energy. Lasting memories.</p></div>`
  });
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

// Health endpoint for hosting checks.
app.get("/api/health", (_req, res) => res.json({ ok: true, event: "GABOS", eventDate: "2026-11-17", paymentConfigured: requireDarajaConfig().length === 0 }));

app.post("/api/checkout", async (req, res) => {
  const { name, email, phone: rawPhone, ticketType, quantity } = req.body || {};
  if (typeof name !== "string" || name.trim().length < 2 || name.length > 100) return res.status(400).json({ error: "Enter your full name." });
  if (typeof email !== "string" || email.length > 200 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (!TICKETS[ticketType]) return res.status(400).json({ error: "Choose a valid ticket type." });
  const q = Number(quantity);
  if (!Number.isInteger(q) || q < 1 || q > 10) return res.status(400).json({ error: "Choose between 1 and 10 ticket units." });
  let phone;
  try { phone = normalizeKenyanPhone(rawPhone); } catch (err) { return res.status(400).json({ error: err.message }); }
  const ticket = TICKETS[ticketType];
  const order = { id: crypto.randomUUID(), name: name.trim(), email: email.trim(), phone, ticket_type: ticketType, quantity: q, amount: ticket.price*q, status: "pending", created_at: now() };
  db.prepare("INSERT INTO orders (id,name,email,phone,ticket_type,quantity,amount,status,created_at) VALUES (@id,@name,@email,@phone,@ticket_type,@quantity,@amount,@status,@created_at)").run(order);
  try {
    const response = await startStkPush(order, phone);
    res.status(202).json({ orderId: order.id, message: "M-Pesa prompt requested. Check your phone and enter your M-Pesa PIN only in the official M-Pesa prompt." });
  } catch (err) {
    db.prepare("UPDATE orders SET status='failed' WHERE id=?").run(order.id);
    res.status(503).json({ error: err.message || "Could not start M-Pesa checkout." });
  }
});

// Safaricom sends the STK callback here. Never issue tickets from the browser.
app.post("/api/mpesa/callback", async (req, res) => {
  // Acknowledge quickly; Daraja may retry callbacks.
  res.json({ ResultCode: 0, ResultDesc: "Accepted" });
  try {
    const callback = req.body?.Body?.stkCallback;
    if (!callback?.CheckoutRequestID) return;
    const order = db.prepare("SELECT * FROM orders WHERE checkout_request_id=?").get(callback.CheckoutRequestID);
    if (!order || order.status === "paid") return;
    if (Number(callback.ResultCode) !== 0) {
      db.prepare("UPDATE orders SET status='failed' WHERE id=? AND status='pending'").run(order.id);
      return;
    }
    // Confirm the callback by querying Daraja before marking paid.
    const query = await queryStkStatus(callback.CheckoutRequestID);
    const resultCode = Number(query.ResultCode);
    if (resultCode !== 0) {
      console.error("STK query did not confirm success for", order.id, query);
      return;
    }
    const metadata = callback.CallbackMetadata?.Item || [];
    const receipt = metadata.find(x => x.Name === "MpesaReceiptNumber")?.Value || null;
    const update = db.prepare("UPDATE orders SET status='paid',mpesa_receipt=?,paid_at=? WHERE id=? AND status='pending'").run(receipt, now(), order.id);
    if (update.changes) await issueTickets(order.id);
  } catch (err) { console.error("M-Pesa callback handling failed:", err); }
});

app.get("/api/orders/:id", (req, res) => {
  const order = db.prepare("SELECT id,status,amount,ticket_type,quantity,created_at,paid_at FROM orders WHERE id=?").get(req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  res.json({ ...order, message: order.status === "paid" ? "Payment confirmed." : order.status === "failed" ? "Payment failed or was cancelled." : "Payment is still pending." });
});

app.get("/api/tickets/verify/:ticketNumber", (req, res) => {
  const ticket = db.prepare(`SELECT t.ticket_number,t.status,t.created_at,o.ticket_type,o.name,o.status AS order_status
    FROM tickets t JOIN orders o ON o.id=t.order_id WHERE t.ticket_number=?`).get(req.params.ticketNumber);
  if (!ticket) return res.status(404).json({ valid: false, message: "Ticket not found." });
  res.json({ valid: ticket.status === "valid" && ticket.order_status === "paid", ticketNumber: ticket.ticket_number, ticketType: TICKETS[ticket.ticket_type].label, attendee: ticket.name, status: ticket.status });
});

app.use(express.static(path.join(__dirname, "..", "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));
app.listen(PORT, () => console.log(`GABOS running on http://localhost:${PORT}`));
